%% Question 4
% Two variants of cardiac physiology were described in lecture-one of fetal 
% circulation and the other of a fetal abnormality called tetralogy of Fallot.
% Develop mathematical models of each similar to the approach taken in clas